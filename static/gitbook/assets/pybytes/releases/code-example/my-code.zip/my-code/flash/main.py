import pycom
pycom.heartbeat(False)  # disable the heartbeat LED
pycom.rgbled(0x00FF)    # make the LED light up in Blue color
